SET IDENTITY_INSERT [CMS_UICulture] ON
INSERT INTO [CMS_UICulture] ([UICultureID], [UICultureName], [UICultureCode], [UICultureGUID], [UICultureLastModified]) VALUES (23, N'Czech', N'cs-cz', '0f367ea3-255c-4a76-897d-73659c789bb0', '20110325 16:54:36')
INSERT INTO [CMS_UICulture] ([UICultureID], [UICultureName], [UICultureCode], [UICultureGUID], [UICultureLastModified]) VALUES (11, N'English', N'en-us', '356a7bb3-5b11-4d83-bbc4-964aafd6d60a', '20080820 13:52:32')
INSERT INTO [CMS_UICulture] ([UICultureID], [UICultureName], [UICultureCode], [UICultureGUID], [UICultureLastModified]) VALUES (84, N'Slovak', N'sk-sk', '15a8b635-85b7-435c-8113-5cc98e4a2986', '20110328 14:08:31')
SET IDENTITY_INSERT [CMS_UICulture] OFF
