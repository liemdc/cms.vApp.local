SET IDENTITY_INSERT [CMS_WorkflowStep] ON
INSERT INTO [CMS_WorkflowStep] ([StepID], [StepDisplayName], [StepName], [StepOrder], [StepWorkflowID], [StepGUID], [StepLastModified]) VALUES (1, N'Edit', N'edit', 1, 1, '633c6b94-f891-4a37-ba9c-bd14f76bcde8', '20080820 13:53:20')
INSERT INTO [CMS_WorkflowStep] ([StepID], [StepDisplayName], [StepName], [StepOrder], [StepWorkflowID], [StepGUID], [StepLastModified]) VALUES (2, N'Published', N'published', 4, 1, '4391d9e9-5954-41d0-b082-fef4b09bcff3', '20111003 13:54:21')
INSERT INTO [CMS_WorkflowStep] ([StepID], [StepDisplayName], [StepName], [StepOrder], [StepWorkflowID], [StepGUID], [StepLastModified]) VALUES (20, N'Archived', N'archived', 5, 1, '9d987f6a-c420-49d8-aafd-898b7ec4ece9', '20111003 13:54:22')
INSERT INTO [CMS_WorkflowStep] ([StepID], [StepDisplayName], [StepName], [StepOrder], [StepWorkflowID], [StepGUID], [StepLastModified]) VALUES (254, N'Edit', N'edit', 1, 46, '6d3da94a-c830-408a-9738-65bf1c593551', '20100907 10:37:52')
INSERT INTO [CMS_WorkflowStep] ([StepID], [StepDisplayName], [StepName], [StepOrder], [StepWorkflowID], [StepGUID], [StepLastModified]) VALUES (255, N'Published', N'published', 2, 46, '931aa2e0-ae9d-4cd4-a07c-c01bd6dd4080', '20100907 10:37:52')
INSERT INTO [CMS_WorkflowStep] ([StepID], [StepDisplayName], [StepName], [StepOrder], [StepWorkflowID], [StepGUID], [StepLastModified]) VALUES (256, N'Archived', N'archived', 3, 46, '8750289f-6686-4aa3-825c-b3cb89644fea', '20100907 10:37:52')
SET IDENTITY_INSERT [CMS_WorkflowStep] OFF
