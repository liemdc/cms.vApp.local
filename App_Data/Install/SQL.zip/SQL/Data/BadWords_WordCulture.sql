INSERT INTO [BadWords_WordCulture] ([WordID], [CultureID]) VALUES (177, 1)
INSERT INTO [BadWords_WordCulture] ([WordID], [CultureID]) VALUES (177, 2)
INSERT INTO [BadWords_WordCulture] ([WordID], [CultureID]) VALUES (177, 3)
